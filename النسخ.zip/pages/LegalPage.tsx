import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};


const PrivacyPolicyContent = () => {
    const { t } = useTranslation();
    return (
        <div className="space-y-4 text-theme-secondary leading-relaxed">
            <h2 className="text-3xl font-bold text-theme-primary mb-4">{t('legalPage.tab_privacy')}</h2>
            <p><em>{t('legalPage.last_updated', { date: new Date().toLocaleDateString() })}</em></p>
            <p>{t('legalPage.privacy.p1')}</p>
            
            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.privacy.h1')}</h3>
            <p>{t('legalPage.privacy.p2')}</p>
            <ul className="list-disc ltr:list-inside rtl:list-outside rtl:mr-6 space-y-2 ltr:pl-4 rtl:pr-4">
                <li><strong>{t('legalPage.privacy.item1_title')}:</strong> {t('legalPage.privacy.item1_desc')}</li>
                <li><strong>{t('legalPage.privacy.item2_title')}:</strong> {t('legalPage.privacy.item2_desc')}</li>
                <li><strong>{t('legalPage.privacy.item3_title')}:</strong> {t('legalPage.privacy.item3_desc')}</li>
                <li><strong>{t('legalPage.privacy.item4_title')}:</strong> {t('legalPage.privacy.item4_desc')}</li>
            </ul>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.privacy.h2')}</h3>
            <p>{t('legalPage.privacy.p3')}</p>
            <ul className="list-disc ltr:list-inside rtl:list-outside rtl:mr-6 space-y-2 ltr:pl-4 rtl:pr-4">
                <li>{t('legalPage.privacy.use1')}</li>
                <li>{t('legalPage.privacy.use2')}</li>
                <li>{t('legalPage.privacy.use3')}</li>
                <li>{t('legalPage.privacy.use4')}</li>
                <li>{t('legalPage.privacy.use5')}</li>
            </ul>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.privacy.h3')}</h3>
            <p>{t('legalPage.privacy.p4')}</p>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.privacy.h4')}</h3>
            <p>{t('legalPage.privacy.p5')}</p>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.privacy.h5')}</h3>
            <p>{t('legalPage.privacy.p6')} <Link to="/contact" className="text-[#00a7e1] hover:underline">{t('legalPage.privacy.contact_link')}</Link>.</p>
        </div>
    );
};

const TermsAndConditionsContent = () => {
    const { t } = useTranslation();
    return (
        <div className="space-y-4 text-theme-secondary leading-relaxed">
            <h2 className="text-3xl font-bold text-theme-primary mb-4">{t('legalPage.tab_terms')}</h2>
            <p><em>{t('legalPage.last_updated', { date: new Date().toLocaleDateString() })}</em></p>
            <p>{t('legalPage.terms.p1')}</p>
            
            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.terms.h1')}</h3>
            <p>{t('legalPage.terms.p2')}</p>
            
            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.terms.h2')}</h3>
            <p>{t('legalPage.terms.p3')}</p>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.terms.h3')}</h3>
            <p>{t('legalPage.terms.p4')}</p>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.terms.h4')}</h3>
            <p>{t('legalPage.terms.p5')}</p>

            <h3 className="text-2xl font-bold text-theme-primary mt-6 mb-3">{t('legalPage.terms.h5')}</h3>
            <p>{t('legalPage.terms.p6')}</p>
        </div>
    );
};

const LegalPage: React.FC = () => {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('privacy'); // 'privacy' or 'terms'
  const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
  const [contentRef, contentInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.1 });

  const tabButtonClasses = "px-6 py-3 font-semibold rounded-t-lg transition-colors duration-300 focus:outline-none -mb-px";
  const activeTabClasses = "border-b-2 border-[#00a7e1] text-[#00a7e1]";
  const inactiveTabClasses = "text-theme-secondary hover:text-theme-primary border-b-2 border-transparent";

  return (
    <div className="py-20 bg-theme-bg-alt overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-12 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('legalPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('legalPage.subtitle')}</p>
        </header>

        <div ref={contentRef} className={`max-w-4xl mx-auto opacity-0 ${contentInView ? 'fade-in-up delay-1' : ''}`}>
          {/* Tab Navigation */}
          <div className="border-b border-theme mb-8">
            <nav className="flex space-x-1 sm:space-x-4 rtl:space-x-reverse" aria-label="Tabs">
              <button
                onClick={() => setActiveTab('privacy')}
                className={`${tabButtonClasses} ${activeTab === 'privacy' ? activeTabClasses : inactiveTabClasses}`}
                aria-current={activeTab === 'privacy' ? 'page' : undefined}
              >
                {t('legalPage.tab_privacy')}
              </button>
              <button
                onClick={() => setActiveTab('terms')}
                className={`${tabButtonClasses} ${activeTab === 'terms' ? activeTabClasses : inactiveTabClasses}`}
                aria-current={activeTab === 'terms' ? 'page' : undefined}
              >
                {t('legalPage.tab_terms')}
              </button>
            </nav>
          </div>

          {/* Content */}
          <div className="bg-theme-card p-8 sm:p-12 rounded-lg border border-theme shadow-lg">
            {activeTab === 'privacy' ? <PrivacyPolicyContent /> : <TermsAndConditionsContent />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalPage;