import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const FaqItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-theme">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full text-start flex justify-between items-center py-6 px-2 focus:outline-none"
        aria-expanded={isOpen}
      >
        <h3 className="text-lg font-semibold text-theme-primary">{question}</h3>
        <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00a7e1]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
        </span>
      </button>
      <div className={`overflow-hidden transition-all duration-500 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
        <p className="pb-6 px-2 text-theme-secondary leading-relaxed">{answer}</p>
      </div>
    </div>
  );
};

const FaqPage: React.FC = () => {
    const { t } = useTranslation();
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
    const [faqListRef, faqListInView] = useScrollAnimation({ triggerOnce: true });

  const faqs = [
    { question: t('faqPage.q1'), answer: t('faqPage.a1') },
    { question: t('faqPage.q2'), answer: t('faqPage.a2') },
    { question: t('faqPage.q3'), answer: t('faqPage.a3') },
    { question: t('faqPage.q4'), answer: t('faqPage.a4') },
    { question: t('faqPage.q5'), answer: t('faqPage.a5') },
    { question: t('faqPage.q6'), answer: t('faqPage.a6') },
    { question: t('faqPage.q7'), answer: t('faqPage.a7') },
    { question: t('faqPage.q8'), answer: t('faqPage.a8') },
  ];

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('faqPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('faqPage.subtitle')}</p>
        </header>

        <div ref={faqListRef} className={`max-w-3xl mx-auto opacity-0 ${faqListInView ? 'fade-in-up delay-1' : ''}`}>
          {faqs.map((faq, index) => (
            <FaqItem key={index} question={faq.question} answer={faq.answer} />
          ))}
        </div>
        
      </div>
    </div>
  );
};

export default FaqPage;