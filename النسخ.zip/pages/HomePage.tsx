import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AiBrainIcon, SentimentIcon, WhaleTrackerIcon, TransparencyIcon, InnovationIcon, CommunityIcon, PriceChartIcon, TokenToolIcon } from '../components/icons/GradientIcons';
import { useTheme } from '../components/ThemeContext';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};


const HomePage: React.FC = () => {
  const { t } = useTranslation();
  const [featuresRef, featuresInView] = useScrollAnimation({ triggerOnce: true });
  const [whyUsRef, whyUsInView] = useScrollAnimation({ triggerOnce: true });
  const [ctaRef, ctaInView] = useScrollAnimation({ triggerOnce: true });
  const [newsletterRef, newsletterInView] = useScrollAnimation({ triggerOnce: true });

  // Newsletter form state
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const [showSubContent, setShowSubContent] = useState(false);
  const dynamicPhrases = t('homePage.hero.dynamic_phrases', { returnObjects: true }) as string[];

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { theme } = useTheme();

  // Particle Animation Effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    let animationFrameId: number;

    const setCanvasDimensions = () => {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
    };
    setCanvasDimensions();
    
    class Particle {
      x: number; y: number; radius: number; vx: number; vy: number;
      constructor(x: number, y: number, radius: number, vx: number, vy: number) {
        this.x = x; this.y = y; this.radius = radius; this.vx = vx; this.vy = vy;
      }
      draw() {
        if(!ctx) return;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        ctx.fillStyle = theme === 'dark' ? '#00a7e1' : '#0072ff';
        ctx.fill();
      }
      update() {
        if (this.x + this.radius > canvas.width || this.x - this.radius < 0) this.vx = -this.vx;
        if (this.y + this.radius > canvas.height || this.y - this.radius < 0) this.vy = -this.vy;
        this.x += this.vx;
        this.y += this.vy;
        this.draw();
      }
    }

    const particlesArray: Particle[] = [];
    const initParticles = () => {
        particlesArray.length = 0;
        const numberOfParticles = Math.floor((canvas.width * canvas.height) / 15000);
        for (let i = 0; i < numberOfParticles; i++) {
            const radius = Math.random() * 1.5 + 1;
            const x = Math.random() * (canvas.width - radius * 2) + radius;
            const y = Math.random() * (canvas.height - radius * 2) + radius;
            const vx = (Math.random() - 0.5) * 0.5;
            const vy = (Math.random() - 0.5) * 0.5;
            particlesArray.push(new Particle(x, y, radius, vx, vy));
        }
    }
    initParticles();

    const connect = () => {
        const maxDistance = 150;
        for (let a = 0; a < particlesArray.length; a++) {
            for (let b = a + 1; b < particlesArray.length; b++) {
                const distance = Math.sqrt(
                    (particlesArray[a].x - particlesArray[b].x) ** 2 +
                    (particlesArray[a].y - particlesArray[b].y) ** 2
                );
                if (distance < maxDistance) {
                    const opacity = 1 - distance / maxDistance;
                    ctx.strokeStyle = theme === 'dark' 
                        ? `rgba(0, 201, 167, ${opacity})`
                        : `rgba(0, 114, 255, ${opacity})`;
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(particlesArray[a].x, particlesArray[a].y);
                    ctx.lineTo(particlesArray[b].x, particlesArray[b].y);
                    ctx.stroke();
                }
            }
        }
    };
    
    const animate = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (const particle of particlesArray) particle.update();
        connect();
        animationFrameId = requestAnimationFrame(animate);
    };
    
    animate();

    const handleResize = () => {
        cancelAnimationFrame(animationFrameId);
        setCanvasDimensions();
        initParticles();
        animate();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme]);

  useEffect(() => {
    const timer = setTimeout(() => {
        setShowSubContent(true);
    }, 1000); // Show sub-content after a short delay
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('idle');
    setMessage('');

    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setStatus('error');
      setMessage(t('footer.newsletter_error_invalid'));
      return;
    }

    // Mock submission
    console.log('Subscribing with email from homepage:', email);
    setStatus('success');
    
    // Reset form after a few seconds
    setTimeout(() => {
        setStatus('idle');
        setEmail('');
    }, 5000);
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative flex items-center justify-center text-center py-20 md:py-32 bg-theme-bg">
        <canvas ref={canvasRef} className="hero-canvas"></canvas>
        <div className="container mx-auto px-6 relative z-[2]">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-theme-primary tracking-tight leading-tight mb-4 min-h-[100px] md:min-h-[168px] lg:min-h-[200px]">
            <span className="fade-in">{t('homePage.hero.line1')}</span>{' '}
            <span className="dynamic-text-wrapper">
              {dynamicPhrases.map((phrase) => (
                <span key={phrase} className="gradient-text">{phrase}</span>
              ))}
            </span>
            <br className="hidden lg:block" />
            <span className="fade-in delay-1">{t('homePage.hero.line3')}</span>
          </h1>

          {showSubContent && (
            <>
              <p className="max-w-3xl mx-auto text-lg md:text-xl text-theme-secondary mb-8 fade-in-up">
                {t('homePage.hero.description')}
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 rtl:space-x-reverse fade-in-up delay-1 justify-center">
                <Link 
                  to="/features" 
                  className="gradient-bg text-white font-semibold py-3 px-8 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-[#00a7e1]/30">
                  {t('homePage.hero.explore_features_btn')}
                </Link>
                <Link 
                  to="/tokenomics" 
                  className="bg-theme-card text-[#00c9a7] font-semibold py-3 px-8 rounded-lg border-2 border-[#00c9a7] hover:bg-[#00c9a7] hover:text-white transition-all duration-300 transform hover:scale-105">
                  {t('homePage.hero.view_tokenomics_btn')}
                </Link>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Key Features Section */}
      <section ref={featuresRef} className="py-20 bg-theme-bg-alt">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <h2 className={`text-4xl font-extrabold text-theme-primary mb-4 opacity-0 ${featuresInView ? 'fade-in-up' : ''}`}>{t('homePage.features_section.title')}</h2>
            <p className={`text-lg text-theme-secondary mb-12 max-w-2xl mx-auto opacity-0 ${featuresInView ? 'fade-in-up delay-1' : ''}`}>{t('homePage.features_section.description')}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* AI-Powered Token Analysis */}
            <div className={`tilt-card opacity-0 ${featuresInView ? 'fade-in-up delay-2' : ''}`}>
              <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner text-left rtl:text-right">
                <div className="mb-4"><AiBrainIcon className="h-12 w-12" /></div>
                <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('featuresPage.feature1_title')}</h3>
                <p className="text-theme-secondary">{t('featuresPage.feature1_desc')}</p>
              </div>
            </div>
            {/* Live Price Tracking */}
            <div className={`tilt-card opacity-0 ${featuresInView ? 'fade-in-up delay-3' : ''}`}>
              <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner text-left rtl:text-right">
                <div className="mb-4"><PriceChartIcon className="h-12 w-12" /></div>
                <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('featuresPage.feature2_title')}</h3>
                <p className="text-theme-secondary">{t('featuresPage.feature2_desc')}</p>
              </div>
            </div>
            {/* Social Sentiment Analysis */}
            <div className={`tilt-card opacity-0 ${featuresInView ? 'fade-in-up delay-4' : ''}`}>
              <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner text-left rtl:text-right">
                <div className="mb-4"><SentimentIcon className="h-12 w-12" /></div>
                <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('featuresPage.feature3_title')}</h3>
                <p className="text-theme-secondary">{t('featuresPage.feature3_desc')}</p>
              </div>
            </div>
            {/* Whale Tracking */}
            <div className={`tilt-card opacity-0 ${featuresInView ? 'fade-in-up delay-5' : ''}`}>
              <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner text-left rtl:text-right">
                <div className="mb-4"><WhaleTrackerIcon className="h-12 w-12" /></div>
                <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('featuresPage.feature4_title')}</h3>
                <p className="text-theme-secondary">{t('featuresPage.feature4_desc')}</p>
              </div>
            </div>
            {/* Solana Token Creation Tool (Full Width) */}
            <div className={`tilt-card md:col-span-2 opacity-0 ${featuresInView ? 'fade-in-up delay-6' : ''}`}>
              <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner text-left rtl:text-right">
                <div className="mb-4"><TokenToolIcon className="h-12 w-12" /></div>
                <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('featuresPage.feature5_title')}</h3>
                <p className="text-theme-secondary">{t('featuresPage.feature5_desc')}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section ref={whyUsRef} className="py-20 bg-theme-bg">
          <div className="container mx-auto px-6 text-center">
              <h2 className={`text-4xl font-extrabold text-theme-primary mb-4 opacity-0 ${whyUsInView ? 'fade-in-up' : ''}`}>{t('homePage.why_us_section.title')}</h2>
              <p className={`text-lg text-theme-secondary mb-12 max-w-2xl mx-auto opacity-0 ${whyUsInView ? 'fade-in-up delay-1' : ''}`}>{t('homePage.why_us_section.description')}</p>
              <div className="grid md:grid-cols-3 gap-8 text-left rtl:text-right">
                   <div className={`bg-theme-bg-alt p-8 rounded-lg ltr:border-l-4 rtl:border-r-4 border-[#00c9a7] opacity-0 ${whyUsInView ? 'fade-in-up delay-2' : ''}`}>
                      <div className="mb-4"><TransparencyIcon className="h-10 w-10" /></div>
                      <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('homePage.why_us_section.value1_title')}</h3>
                      <p className="text-theme-secondary">{t('homePage.why_us_section.value1_desc')}</p>
                  </div>
                  <div className={`bg-theme-bg-alt p-8 rounded-lg ltr:border-l-4 rtl:border-r-4 border-[#00c9a7] opacity-0 ${whyUsInView ? 'fade-in-up delay-3' : ''}`}>
                      <div className="mb-4"><InnovationIcon className="h-10 w-10" /></div>
                      <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('homePage.why_us_section.value2_title')}</h3>
                      <p className="text-theme-secondary">{t('homePage.why_us_section.value2_desc')}</p>
                  </div>
                  <div className={`bg-theme-bg-alt p-8 rounded-lg ltr:border-l-4 rtl:border-r-4 border-[#00c9a7] opacity-0 ${whyUsInView ? 'fade-in-up delay-4' : ''}`}>
                      <div className="mb-4"><CommunityIcon className="h-10 w-10" /></div>
                      <h3 className="text-2xl font-bold mb-2 text-theme-primary">{t('homePage.why_us_section.value3_title')}</h3>
                      <p className="text-theme-secondary">{t('homePage.why_us_section.value3_desc')}</p>
                  </div>
              </div>
          </div>
      </section>
      
      {/* Final CTA Section */}
      <section ref={ctaRef} className="py-20 cta-dark-section">
          <div className="container mx-auto px-6 text-center">
              <h2 className={`text-4xl font-extrabold mb-4 opacity-0 ${ctaInView ? 'fade-in-up' : ''}`}>{t('homePage.cta_section.title')}</h2>
              <p className={`text-lg text-gray-300 mb-8 max-w-2xl mx-auto opacity-0 ${ctaInView ? 'fade-in-up delay-1' : ''}`}>{t('homePage.cta_section.description')}</p>
              <Link 
                to="/features" 
                className={`gradient-bg text-white font-semibold py-3 px-8 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-[#00a7e1]/30 opacity-0 ${ctaInView ? 'fade-in-up delay-2' : ''}`}>
                {t('homePage.cta_section.explore_btn')}
              </Link>
          </div>
      </section>

      {/* Newsletter Section */}
      <section ref={newsletterRef} className="py-20 bg-theme-bg">
        <div className={`container mx-auto px-6 text-center opacity-0 ${newsletterInView ? 'fade-in-up' : ''}`}>
            <div className="w-full max-w-xl mx-auto">
                <h2 className="text-4xl font-extrabold text-theme-primary mb-4">{t('footer.newsletter_title')}</h2>
                <p className="text-lg text-theme-secondary mb-8">{t('footer.newsletter_description')}</p>
                {status === 'success' ? (
                    <div className="bg-green-100 dark:bg-green-900/50 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300 px-4 py-3 rounded-lg" role="alert">
                        <strong className="font-bold">{t('footer.newsletter_success_title')}</strong>
                        <span className="block sm:inline ltr:ml-2 rtl:mr-2">{t('footer.newsletter_success_desc')}</span>
                    </div>
                ) : (
                    <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4">
                        <label htmlFor="newsletter-email-homepage" className="sr-only">{t('footer.newsletter_placeholder')}</label>
                        <input
                            id="newsletter-email-homepage"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder={t('footer.newsletter_placeholder')}
                            className="w-full bg-theme-card border border-theme rounded-md py-3 px-4 text-theme-primary focus:ring-2 focus:ring-[#00a7e1] focus:border-transparent transition"
                            aria-label={t('footer.newsletter_placeholder')}
                            required
                        />
                        <button
                            type="submit"
                            className="gradient-bg text-white font-semibold py-3 px-6 rounded-lg hover:opacity-90 transition-opacity whitespace-nowrap"
                        >
                            {t('footer.newsletter_button')}
                        </button>
                    </form>
                )}
                {status === 'error' && (
                    <p className="text-red-500 text-sm mt-2 text-start ltr:pl-1 rtl:pr-1">{message}</p>
                )}
            </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;