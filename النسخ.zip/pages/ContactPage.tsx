import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { EmailIcon } from '../components/icons/GradientIcons';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const ContactPage: React.FC = () => {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
  const [formRef, formInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.3 });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form Submitted:', formData);
    setSubmitted(true);
    // In a real application, you would send this data to a backend server or email service.
    setTimeout(() => {
        setSubmitted(false);
        setFormData({ name: '', email: '', message: '' });
    }, 5000)
  };

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-12 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('contactPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('contactPage.subtitle')}</p>
        </header>

        <div ref={formRef} className={`max-w-4xl mx-auto grid md:grid-cols-2 gap-12 bg-theme-card p-8 rounded-lg border border-theme shadow-xl opacity-0 ${formInView ? 'fade-in-up delay-1' : ''}`}>
            <div className="flex flex-col justify-center">
                 <h2 className="text-2xl font-bold text-theme-primary mb-4">{t('contactPage.info_title')}</h2>
                 <p className="text-theme-secondary mb-6">{t('contactPage.info_desc')}</p>
                 <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <EmailIcon className="h-6 w-6" />
                    <a href="mailto:contact@artofele.com" className="text-[#00a7e1] hover:text-[#0072ff] transition-colors">contact@artofele.com</a>
                 </div>
            </div>
            <div>
            {submitted ? (
                 <div className="flex flex-col items-center justify-center h-full text-center bg-theme-bg-alt p-6 rounded-md">
                    <h3 className="text-2xl font-bold text-theme-primary mb-2">{t('contactPage.success_title')}</h3>
                    <p className="text-theme-secondary">{t('contactPage.success_desc')}</p>
                 </div>
            ) : (
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                      <input type="text" name="name" id="name" required value={formData.name} onChange={handleChange} className="form-input" placeholder=" " />
                      <label htmlFor="name" className="form-label">{t('contactPage.form_name')}</label>
                    </div>
                    <div className="form-group">
                      <input type="email" name="email" id="email" required value={formData.email} onChange={handleChange} className="form-input" placeholder=" " />
                      <label htmlFor="email" className="form-label">{t('contactPage.form_email')}</label>
                    </div>
                    <div className="form-group">
                      <textarea name="message" id="message" rows={5} required value={formData.message} onChange={handleChange} className="form-input" placeholder=" "></textarea>
                      <label htmlFor="message" className="form-label">{t('contactPage.form_message')}</label>
                    </div>
                    <button type="submit" className="w-full gradient-bg text-white font-semibold py-3 px-6 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-[#00a7e1]/30 mt-6">
                    {t('contactPage.form_button')}
                    </button>
                </form>
            )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;