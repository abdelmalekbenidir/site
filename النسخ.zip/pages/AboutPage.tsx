import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { TransparencyIcon, InnovationIcon, CommunityIcon } from '../components/icons/GradientIcons';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const Section: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
    <div className={`mb-16 ${className}`}>
        <h2 className="text-4xl font-extrabold text-theme-primary text-center mb-4">{title}</h2>
        <div className="w-24 h-1 gradient-bg mx-auto mb-10"></div>
        {children}
    </div>
);

const ValueCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode; className?: string }> = ({ icon, title, children, className }) => (
    <div className={className}>
      <div className="bg-theme-bg-alt p-8 rounded-lg ltr:border-l-4 rtl:border-r-4 border-[#00c9a7] h-full">
        <div className="mb-4">{icon}</div>
        <h3 className="text-2xl font-bold mb-2 text-theme-primary">{title}</h3>
        <p className="text-theme-secondary">{children}</p>
      </div>
    </div>
);

const TeamMemberCard: React.FC<{ name: string; role: string; className?: string }> = ({ name, role, className }) => (
    <div className={`bg-theme-card p-6 rounded-lg shadow-md border border-theme text-center transition-all duration-300 hover:shadow-xl hover:scale-105 ${className}`}>
        <div className="w-24 h-24 rounded-full bg-theme-bg-alt mx-auto mb-4 flex items-center justify-center overflow-hidden">
             <svg className="w-16 h-16 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path></svg>
        </div>
        <h3 className="text-xl font-bold text-theme-primary">{name}</h3>
        <p className="text-[#00a7e1]">{role}</p>
    </div>
);

const AboutPage: React.FC = () => {
    const { t } = useTranslation();
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
    const [missionRef, missionInView] = useScrollAnimation({ triggerOnce: true });
    const [visionRef, visionInView] = useScrollAnimation({ triggerOnce: true });
    const [valuesRef, valuesInView] = useScrollAnimation({ triggerOnce: true });
    const [teamRef, teamInView] = useScrollAnimation({ triggerOnce: true });

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('aboutPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4 max-w-3xl mx-auto">{t('aboutPage.subtitle')}</p>
        </header>

        <div ref={missionRef}>
            <Section title={t('aboutPage.mission_title')} className={`opacity-0 ${missionInView ? 'fade-in-up' : ''}`}>
              <p className="text-center text-lg text-theme-secondary max-w-3xl mx-auto leading-relaxed">
                {t('aboutPage.mission_desc')}
              </p>
            </Section>
        </div>

        <div ref={visionRef}>
            <Section title={t('aboutPage.vision_title')} className={`opacity-0 ${visionInView ? 'fade-in-up' : ''}`}>
               <p className="text-center text-lg text-theme-secondary max-w-3xl mx-auto leading-relaxed">
                {t('aboutPage.vision_desc')}
              </p>
            </Section>
        </div>
        
        <div ref={valuesRef}>
            <Section title={t('aboutPage.values_title')} className={`opacity-0 ${valuesInView ? 'fade-in-up' : ''}`}>
                <div className="grid md:grid-cols-3 gap-8">
                     <ValueCard icon={<TransparencyIcon className="h-10 w-10"/>} title={t('aboutPage.value1_title')} className={`opacity-0 ${valuesInView ? 'fade-in-up delay-1' : ''}`}>
                        {t('aboutPage.value1_desc')}
                     </ValueCard>
                     <ValueCard icon={<InnovationIcon className="h-10 w-10"/>} title={t('aboutPage.value2_title')} className={`opacity-0 ${valuesInView ? 'fade-in-up delay-2' : ''}`}>
                        {t('aboutPage.value2_desc')}
                     </ValueCard>
                     <ValueCard icon={<CommunityIcon className="h-10 w-10"/>} title={t('aboutPage.value3_title')} className={`opacity-0 ${valuesInView ? 'fade-in-up delay-3' : ''}`}>
                        {t('aboutPage.value3_desc')}
                     </ValueCard>
                </div>
            </Section>
        </div>

        <div ref={teamRef}>
            <Section title={t('aboutPage.team_title')} className={`opacity-0 ${teamInView ? 'fade-in-up' : ''}`}>
                 <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <TeamMemberCard name={t('aboutPage.team_member1_name')} role={t('aboutPage.team_member1_role')} className={`opacity-0 ${teamInView ? 'fade-in-up delay-1' : ''}`} />
                    <TeamMemberCard name={t('aboutPage.team_member2_name')} role={t('aboutPage.team_member2_role')} className={`opacity-0 ${teamInView ? 'fade-in-up delay-2' : ''}`} />
                    <TeamMemberCard name={t('aboutPage.team_member3_name')} role={t('aboutPage.team_member3_role')} className={`opacity-0 ${teamInView ? 'fade-in-up delay-3' : ''}`} />
                    <TeamMemberCard name={t('aboutPage.team_member4_name')} role={t('aboutPage.team_member4_role')} className={`opacity-0 ${teamInView ? 'fade-in-up delay-4' : ''}`} />
                 </div>
            </Section>
        </div>

      </div>
    </div>
  );
};

export default AboutPage;