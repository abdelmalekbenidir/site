import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { SearchIcon } from '../components/icons/SearchIcon';
import { blogPosts } from '../data/blogPosts';
import { PageIcon, BlogIcon } from '../components/icons/ContentIcons';

// --- Scroll Animation Hook ---
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

// Generate site content index based on current language
const getSiteContent = (t: (key: string) => string) => {
    const pages = [
      { type: 'page', path: '/', title: t('searchPage.content.home_title'), description: t('searchPage.content.home_desc') },
      { type: 'page', path: '/about', title: t('searchPage.content.about_title'), description: t('searchPage.content.about_desc') },
      { type: 'page', path: '/features', title: t('searchPage.content.features_title'), description: t('searchPage.content.features_desc') },
      { type: 'page', path: '/tokenomics', title: t('searchPage.content.tokenomics_title'), description: t('searchPage.content.tokenomics_desc') },
      { type: 'page', path: '/roadmap', title: t('searchPage.content.roadmap_title'), description: t('searchPage.content.roadmap_desc') },
      { type: 'page', path: '/faq', title: t('searchPage.content.faq_title'), description: t('searchPage.content.faq_desc') },
      { type: 'page', path: '/contact', title: t('searchPage.content.contact_title'), description: t('searchPage.content.contact_desc') },
      { type: 'page', path: '/privacy-policy', title: t('searchPage.content.privacy_title'), description: t('searchPage.content.privacy_desc') },
      { type: 'page', path: '/terms-of-use', title: t('searchPage.content.terms_title'), description: t('searchPage.content.terms_desc') },
      { type: 'page', path: '/blog', title: t('searchPage.content.blog_title'), description: t('searchPage.content.blog_desc') },
      { type: 'page', path: '/features', title: t('searchPage.content.feature_ai_title'), description: t('searchPage.content.feature_ai_desc') },
      { type: 'page', path: '/features', title: t('searchPage.content.feature_whale_title'), description: t('searchPage.content.feature_whale_desc') },
      { type: 'page', path: '/features', title: t('searchPage.content.feature_sentiment_title'), description: t('searchPage.content.feature_sentiment_desc') },
      { type: 'page', path: '/features', title: t('searchPage.content.feature_tool_title'), description: t('searchPage.content.feature_tool_desc') },
      { type: 'page', path: '/faq', title: t('searchPage.content.faq_ai_title'), description: t('searchPage.content.faq_ai_desc') },
      { type: 'page', path: '/tokenomics', title: t('searchPage.content.tokenomics_mint_title'), description: t('searchPage.content.tokenomics_mint_desc') },
    ];

    const posts = blogPosts.map(post => ({
        type: 'blog',
        path: `/blog/${post.slug}`,
        title: t(`blogPosts.${post.slug}.title`),
        description: t(`blogPosts.${post.slug}.excerpt`)
    }));

    return [...pages, ...posts];
};

const Highlight: React.FC<{ text: string; highlight: string }> = ({ text, highlight }) => {
    if (!highlight.trim()) {
        return <span>{text}</span>;
    }
    const escapedHighlight = highlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedHighlight})`, 'gi');
    const parts = text.split(regex);

    return (
        <span>
            {parts.map((part, i) =>
                regex.test(part) ? (
                    <mark key={i} className="bg-gradient-to-r from-[#00c9a7]/30 to-[#00a7e1]/30 text-theme-primary rounded px-1 py-0.5 mx-[-1px]">
                        {part}
                    </mark>
                ) : (
                    part
                )
            )}
        </span>
    );
};

interface SearchItem {
  type: 'page' | 'blog';
  path: string;
  title: string;
  description: string;
}

const SearchResultItem: React.FC<{ item: SearchItem; query: string }> = ({ item, query }) => {
    const Icon = item.type === 'blog' ? BlogIcon : PageIcon;

    return (
        <Link 
            to={item.path} 
            className="block p-4 rounded-lg hover:bg-theme-bg-alt focus:bg-theme-bg-alt focus:outline-none focus:ring-2 focus:ring-[#00a7e1] transition-colors duration-200 group"
        >
            <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">
                    <Icon className="w-6 h-6" />
                </div>
                <div className="flex-grow">
                    <h3 className="text-lg font-bold text-theme-primary mb-1">
                        <Highlight text={item.title} highlight={query} />
                    </h3>
                    <p className="text-theme-secondary text-sm">
                        <Highlight text={item.description} highlight={query} />
                    </p>
                    <p className="text-xs text-theme-tertiary mt-2 font-mono group-hover:text-[#00c9a7] transition-colors">
                        {item.path}
                    </p>
                </div>
            </div>
        </Link>
    );
};

const NoResultsIcon: React.FC = () => (
  <svg className="w-16 h-16 text-theme-tertiary mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
    <polyline points="14 2 14 8 20 8"></polyline>
    <circle cx="12" cy="13" r="1"></circle>
    <path d="M12 9v2"></path>
  </svg>
);

const SearchPage: React.FC = () => {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
  const [searchRef, searchInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.3 });

  const siteContent = useMemo(() => getSiteContent(t), [t]);

  const { pages, blog } = useMemo(() => {
    if (!query.trim()) {
      return { pages: [], blog: [] };
    }
    const lowerCaseQuery = query.toLowerCase();

    const results = siteContent
        .map(item => {
            const lowerCaseTitle = item.title.toLowerCase();
            const lowerCaseDescription = item.description.toLowerCase();
            let score = 0;

            if (lowerCaseTitle.includes(lowerCaseQuery)) {
                score += 10;
                if (lowerCaseTitle.startsWith(lowerCaseQuery)) score += 10;
                if (lowerCaseTitle === lowerCaseQuery) score += 30;
            }
            if (lowerCaseDescription.includes(lowerCaseQuery)) score += 5;
            if (item.type === 'blog') score += 2;
            
            return { ...item, score };
        })
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score);

    return {
        pages: results.filter(item => item.type === 'page'),
        blog: results.filter(item => item.type === 'blog'),
    };
  }, [query, siteContent]);
  
  const totalResults = pages.length + blog.length;

  return (
    <div className="py-20 bg-theme-bg overflow-hidden min-h-[calc(100vh-200px)]">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-12 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('searchPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('searchPage.subtitle')}</p>
        </header>
        
        <div ref={searchRef} className={`max-w-3xl mx-auto opacity-0 ${searchInView ? 'fade-in-up delay-1' : ''}`}>
          <div className="relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('searchPage.placeholder')}
              className="w-full bg-theme-card border-2 border-theme rounded-lg py-4 ltr:pl-6 rtl:pr-6 ltr:pr-14 rtl:pl-14 text-lg text-theme-primary focus:ring-2 focus:ring-[#00a7e1] focus:border-transparent transition"
              aria-label={t('searchPage.label')}
              autoFocus
            />
            <div className="absolute inset-y-0 ltr:right-0 rtl:left-0 flex items-center ltr:pr-5 rtl:pl-5 pointer-events-none">
              <SearchIcon className="h-6 w-6" />
            </div>
          </div>

          <div className="mt-8">
            {query && totalResults > 0 && (
              <p className="text-theme-secondary text-sm mb-4 px-2">{t('searchPage.results_found', { count: totalResults })}</p>
            )}
            
            {pages.length > 0 && (
                <section className="mb-8">
                    <h2 className="text-sm font-semibold text-theme-tertiary uppercase tracking-wider mb-3 px-4">{t('searchPage.pages_heading')}</h2>
                    <div className="space-y-1">
                        {pages.map(item => <SearchResultItem key={item.path + item.title} item={item as SearchItem} query={query} />)}
                    </div>
                </section>
            )}
            
            {blog.length > 0 && (
                <section>
                    <h2 className="text-sm font-semibold text-theme-tertiary uppercase tracking-wider mb-3 px-4">{t('searchPage.blog_heading')}</h2>
                    <div className="space-y-1">
                        {blog.map(item => <SearchResultItem key={item.path} item={item as SearchItem} query={query} />)}
                    </div>
                </section>
            )}

            {query && totalResults === 0 && (
              <div className="text-center py-16 bg-theme-bg-alt rounded-lg mt-8 flex flex-col items-center">
                <NoResultsIcon />
                <h3 className="text-xl font-semibold text-theme-primary">{t('searchPage.no_results_title')}</h3>
                <p className="text-theme-secondary mt-2 max-w-xs">{t('searchPage.no_results_desc')}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchPage;