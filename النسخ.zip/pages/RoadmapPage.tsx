import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { CheckmarkIcon } from '../components/icons/RoadmapIcons';

// --- Scroll Animation Hook ---
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};


interface RoadmapItemProps {
  phase: string;
  title: string;
  items: string[];
  isCompleted: boolean;
  isCurrent?: boolean;
  index: number;
}

const RoadmapItem: React.FC<RoadmapItemProps> = ({ phase, title, items, isCompleted, isCurrent = false, index }) => {
  const { t } = useTranslation();
  const [ref, isInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.5 });

  const StatusIcon = () => {
    if (isCompleted) {
      return (
        <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white">
          <CheckmarkIcon className="w-6 h-6" />
        </div>
      );
    }
    if (isCurrent) {
      return (
        <div className="w-10 h-10 rounded-full bg-theme-bg-alt flex items-center justify-center" aria-label={t('roadmapPage.current_phase_aria')}>
          <span className="relative flex h-5 w-5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00a7e1] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-5 w-5 bg-[#0072ff]"></span>
          </span>
        </div>
      );
    }
    return (
       <div className="w-10 h-10 rounded-full bg-theme-bg-alt flex items-center justify-center">
        <div className="w-4 h-4 bg-gray-400 dark:bg-gray-600 rounded-full"></div>
      </div>
    );
  };
  
  const cardBorderColor = isCurrent ? 'border-[#00a7e1]' : 'border-transparent';

  return (
    <div ref={ref} className={`relative flex-shrink-0 w-80 p-4 opacity-0 ${isInView ? `fade-in-up delay-${index}`: ''}`}>
       <div className="roadmap-timeline-item relative">
            <div className="flex flex-col items-center mb-4">
                <StatusIcon />
            </div>

            <div className={`bg-theme-card p-6 rounded-lg border-2 ${cardBorderColor} shadow-md hover:shadow-xl transition-shadow duration-300`}>
                <p className="text-[#00c9a7] font-semibold mb-1 text-sm">{phase}</p>
                <h3 className="text-xl font-bold text-theme-primary mb-4">{title}</h3>
                <ul className="list-disc ltr:list-inside rtl:list-outside rtl:mr-5 text-theme-secondary space-y-2 text-sm">
                {items.map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
                </ul>
            </div>
       </div>
    </div>
  );
};

const RoadmapPage: React.FC = () => {
    const { t } = useTranslation();
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
    const [timelineRef, timelineInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.2 });

  const roadmapPhases = [
    {
      phase: `${t('roadmapPage.phase1_title')}: 1`,
      title: t('roadmapPage.phase1_subtitle'),
      items: [
        t('roadmapPage.phase1_item1'),
        t('roadmapPage.phase1_item2'),
        t('roadmapPage.phase1_item3'),
        t('roadmapPage.phase1_item4')
      ],
      isCompleted: true,
    },
    {
      phase: `${t('roadmapPage.phase2_title')}: 2`,
      title: t('roadmapPage.phase2_subtitle'),
      items: [
        t('roadmapPage.phase2_item1'),
        t('roadmapPage.phase2_item2'),
        t('roadmapPage.phase2_item3'),
        t('roadmapPage.phase2_item4')
      ],
      isCompleted: true,
    },
    {
      phase: `${t('roadmapPage.phase3_title')}: 3`,
      title: t('roadmapPage.phase3_subtitle'),
      items: [
        t('roadmapPage.phase3_item1'),
        t('roadmapPage.phase3_item2'),
        t('roadmapPage.phase3_item3'),
        t('roadmapPage.phase3_item4')
      ],
      isCompleted: false,
      isCurrent: true,
    },
    {
      phase: `${t('roadmapPage.phase4_title')}: 4`,
      title: t('roadmapPage.phase4_subtitle'),
      items: [
        t('roadmapPage.phase4_item1'),
        t('roadmapPage.phase4_item2'),
        t('roadmapPage.phase4_item3'),
        t('roadmapPage.phase4_item4')
      ],
      isCompleted: false,
    },
     {
      phase: `${t('roadmapPage.phase5_title')}: 5`,
      title: t('roadmapPage.phase5_subtitle'),
      items: [
        t('roadmapPage.phase5_item1'),
        t('roadmapPage.phase5_item2'),
        t('roadmapPage.phase5_item3'),
        t('roadmapPage.phase5_item4')
      ],
      isCompleted: false,
    },
  ];

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('roadmapPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('roadmapPage.subtitle')}</p>
        </header>

        <div ref={timelineRef} className={`w-full opacity-0 ${timelineInView ? 'fade-in' : ''}`}>
            <div className="roadmap-container overflow-x-auto pb-8">
                <div className="flex w-max px-4">
                {roadmapPhases.map((phase, index) => (
                    <RoadmapItem key={index} {...phase} index={index} />
                ))}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default RoadmapPage;