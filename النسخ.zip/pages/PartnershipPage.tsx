import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { TechIcon, MarketingCollaborationIcon, DataProviderIcon, PartnershipIcon, CommunityIcon, PriceChartIcon } from '../components/icons/GradientIcons';

// --- Scroll Animation Hook ---
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const PartnershipPage: React.FC = () => {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    companyName: '',
    contactName: '',
    email: '',
    website: '',
    partnershipType: 'tech',
    proposal: '',
  });
  const [isPreparing, setIsPreparing] = useState(false);

  const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
  const [whyPartnerRef, whyPartnerInView] = useScrollAnimation({ triggerOnce: true });
  const [whoWeLookForRef, whoWeLookForInView] = useScrollAnimation({ triggerOnce: true });
  const [formRef, formInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.2 });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isPreparing) return;

    const { companyName, contactName, email, website, partnershipType, proposal } = formData;
    
    // Using `t` for potentially translated partnership types
    const partnershipTypeLabel = t(`partnershipPage.partnership_type_${partnershipType.toLowerCase()}`, partnershipType);

    const subject = t('partnershipPage.email_subject', { companyName });
    const body = t('partnershipPage.email_body', {
        companyName,
        contactName,
        email,
        website: website || 'N/A',
        partnershipType: partnershipTypeLabel,
        proposal,
        interpolation: { escapeValue: false }
    });

    const mailtoLink = `mailto:contact@artofele.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body.trim())}`;
    
    setIsPreparing(true);

    // Give user time to read the message, then redirect.
    setTimeout(() => {
        window.location.href = mailtoLink;
        // Reset state after a delay in case the user cancels the email
        setTimeout(() => {
            setIsPreparing(false);
        }, 3000);
    }, 1500);
  };

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('partnershipPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4 max-w-3xl mx-auto">{t('partnershipPage.subtitle')}</p>
        </header>

        {/* Why Partner Section */}
        <section ref={whyPartnerRef} className="mb-20">
          <h2 className={`text-4xl font-extrabold text-theme-primary text-center mb-4 opacity-0 ${whyPartnerInView ? 'fade-in-up' : ''}`}>{t('partnershipPage.why_partner_title')}</h2>
          <p className={`text-lg text-theme-secondary text-center mb-12 max-w-3xl mx-auto opacity-0 ${whyPartnerInView ? 'fade-in-up delay-1' : ''}`}>{t('partnershipPage.why_partner_desc')}</p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className={`tilt-card opacity-0 ${whyPartnerInView ? 'fade-in-up delay-2' : ''}`}>
                <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner">
                    <PartnershipIcon className="h-10 w-10 mb-4" />
                    <h3 className="text-2xl font-bold text-theme-primary mb-2">{t('partnershipPage.benefit1_title')}</h3>
                    <p className="text-theme-secondary">{t('partnershipPage.benefit1_desc')}</p>
                </div>
            </div>
            <div className={`tilt-card opacity-0 ${whyPartnerInView ? 'fade-in-up delay-3' : ''}`}>
                 <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner">
                    <CommunityIcon className="h-10 w-10 mb-4" />
                    <h3 className="text-2xl font-bold text-theme-primary mb-2">{t('partnershipPage.benefit2_title')}</h3>
                    <p className="text-theme-secondary">{t('partnershipPage.benefit2_desc')}</p>
                </div>
            </div>
            <div className={`tilt-card opacity-0 ${whyPartnerInView ? 'fade-in-up delay-4' : ''}`}>
                 <div className="bg-theme-card p-8 rounded-xl border border-theme h-full tilt-card-inner">
                    <PriceChartIcon className="h-10 w-10 mb-4" />
                    <h3 className="text-2xl font-bold text-theme-primary mb-2">{t('partnershipPage.benefit3_title')}</h3>
                    <p className="text-theme-secondary">{t('partnershipPage.benefit3_desc')}</p>
                </div>
            </div>
          </div>
        </section>

        {/* Who We're Looking For Section */}
        <section ref={whoWeLookForRef} className="mb-20 py-20 bg-theme-bg-alt rounded-lg">
             <div className="container mx-auto px-6">
                <h2 className={`text-4xl font-extrabold text-theme-primary text-center mb-12 opacity-0 ${whoWeLookForInView ? 'fade-in-up' : ''}`}>{t('partnershipPage.who_we_look_for_title')}</h2>
                <div className="grid md:grid-cols-3 gap-8 text-center">
                    <div className={`opacity-0 ${whoWeLookForInView ? 'fade-in-up delay-1' : ''}`}>
                        <TechIcon className="h-12 w-12 mx-auto mb-4"/>
                        <h3 className="text-xl font-bold text-theme-primary mb-2">{t('partnershipPage.type1_title')}</h3>
                        <p className="text-theme-secondary">{t('partnershipPage.type1_desc')}</p>
                    </div>
                    <div className={`opacity-0 ${whoWeLookForInView ? 'fade-in-up delay-2' : ''}`}>
                        <MarketingCollaborationIcon className="h-12 w-12 mx-auto mb-4"/>
                        <h3 className="text-xl font-bold text-theme-primary mb-2">{t('partnershipPage.type2_title')}</h3>
                        <p className="text-theme-secondary">{t('partnershipPage.type2_desc')}</p>
                    </div>
                    <div className={`opacity-0 ${whoWeLookForInView ? 'fade-in-up delay-3' : ''}`}>
                        <DataProviderIcon className="h-12 w-12 mx-auto mb-4"/>
                        <h3 className="text-xl font-bold text-theme-primary mb-2">{t('partnershipPage.type3_title')}</h3>
                        <p className="text-theme-secondary">{t('partnershipPage.type3_desc')}</p>
                    </div>
                </div>
             </div>
        </section>


        {/* Form Section */}
        <section ref={formRef}>
          <div className={`max-w-3xl mx-auto bg-theme-card p-8 rounded-lg border border-theme shadow-xl opacity-0 ${formInView ? 'fade-in-up' : ''}`}>
            <h2 className="text-3xl font-bold text-theme-primary text-center mb-8">{t('partnershipPage.form_title')}</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="form-group md:col-span-2">
                <input type="text" name="companyName" id="companyName" required value={formData.companyName} onChange={handleChange} className="form-input" placeholder=" " />
                <label htmlFor="companyName" className="form-label">{t('partnershipPage.form_company_name')}</label>
              </div>
              <div className="form-group">
                <input type="text" name="contactName" id="contactName" required value={formData.contactName} onChange={handleChange} className="form-input" placeholder=" " />
                <label htmlFor="contactName" className="form-label">{t('partnershipPage.form_contact_name')}</label>
              </div>
              <div className="form-group">
                <input type="email" name="email" id="email" required value={formData.email} onChange={handleChange} className="form-input" placeholder=" " />
                <label htmlFor="email" className="form-label">{t('partnershipPage.form_email')}</label>
              </div>
              <div className="form-group md:col-span-2">
                <input type="text" name="website" id="website" value={formData.website} onChange={handleChange} className="form-input" placeholder=" " />
                <label htmlFor="website" className="form-label">{t('partnershipPage.form_website')}</label>
              </div>
              <div className="form-group md:col-span-2">
                  <label htmlFor="partnershipType" className="text-sm text-theme-secondary mb-2 block">{t('partnershipPage.form_partnership_type')}</label>
                  <select name="partnershipType" id="partnershipType" value={formData.partnershipType} onChange={handleChange} className="form-input !py-3">
                      <option value="tech">{t('partnershipPage.partnership_type_tech')}</option>
                      <option value="marketing">{t('partnershipPage.partnership_type_marketing')}</option>
                      <option value="data">{t('partnershipPage.partnership_type_data')}</option>
                      <option value="other">{t('partnershipPage.partnership_type_other')}</option>
                  </select>
              </div>
              <div className="form-group md:col-span-2">
                <textarea name="proposal" id="proposal" rows={5} required value={formData.proposal} onChange={handleChange} className="form-input" placeholder=" "></textarea>
                <label htmlFor="proposal" className="form-label">{t('partnershipPage.form_proposal')}</label>
              </div>
              <div className="md:col-span-2">
                <button 
                  type="submit" 
                  disabled={isPreparing}
                  className="w-full gradient-bg text-white font-semibold py-3 px-6 rounded-lg hover:opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-[#00a7e1]/30 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isPreparing ? t('partnershipPage.preparing_email') : t('partnershipPage.form_button')}
                </button>
                {isPreparing && (
                    <p className="text-center text-sm text-theme-secondary mt-4 fade-in">
                        {t('partnershipPage.redirect_message')}
                    </p>
                )}
              </div>
            </form>
          </div>
        </section>
      </div>
    </div>
  );
};

export default PartnershipPage;
