import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { blogPosts } from '../data/blogPosts';

const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};


const BlogPostPage: React.FC = () => {
    const { slug } = useParams<{ slug: string }>();
    const { t, i18n } = useTranslation();
    const navigate = useNavigate();
    const post = blogPosts.find(p => p.slug === slug);
    
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
    const [contentRef, contentInView] = useScrollAnimation({ triggerOnce: true });
    
    useEffect(() => {
        if (!post) {
            // Optional: redirect to a 404 page or back to the blog index
        }
    }, [post, navigate]);

    if (!post) {
        return (
            <div className="py-20 bg-theme-bg">
                <div className="container mx-auto px-6 text-center">
                    <h1 className="text-4xl font-bold text-theme-primary mb-4">{t('blogPage.post_not_found_title')}</h1>
                    <p className="text-theme-secondary mb-8">{t('blogPage.post_not_found_desc')}</p>
                    <Link to="/blog" className="gradient-bg text-white font-semibold py-3 px-6 rounded-lg hover:opacity-90 transition-opacity">
                        &larr; {t('blogPage.back_to_blog')}
                    </Link>
                </div>
            </div>
        );
    }

    const postDate = new Date(post.date);
    const formattedDate = new Intl.DateTimeFormat(i18n.language, {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    }).format(postDate);

    const contentParagraphs = t(`blogPosts.${post.slug}.content`, { returnObjects: true }) as string[];

    return (
        <div className="py-20 bg-theme-bg overflow-hidden">
            <div className="container mx-auto px-6">
                <div className="max-w-3xl mx-auto">
                    <div ref={headerRef} className={`opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
                        <Link to="/blog" className="text-[#00a7e1] font-semibold flex items-center gap-2 mb-8 hover:underline">
                             &larr; {t('blogPage.back_to_blog')}
                        </Link>

                        <h1 className="text-4xl md:text-5xl font-extrabold text-theme-primary leading-tight mb-4">
                            {t(`blogPosts.${post.slug}.title`)}
                        </h1>
                        <p className="text-theme-secondary mb-8">
                            {t('blogPage.posted_by', { author: post.author })} {t('blogPage.posted_on', { date: formattedDate })}
                        </p>

                        <img src={post.image} alt={t(`blogPosts.${post.slug}.title`)} className="w-full h-64 md:h-80 object-cover rounded-xl mb-12 border border-theme" />
                    </div>

                    <article ref={contentRef} className={`prose lg:prose-xl text-theme-secondary leading-relaxed space-y-6 opacity-0 ${contentInView ? 'fade-in-up delay-1' : ''}`}>
                         {Array.isArray(contentParagraphs) && contentParagraphs.map((paragraph, index) => (
                            <p key={index}>{paragraph}</p>
                        ))}
                    </article>
                </div>
            </div>
        </div>
    );
};

export default BlogPostPage;
