import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, Sector } from 'recharts';
import { LiquidityIcon, TreasuryIcon, CommunityIcon, MarketingIcon, TagIcon, CubeIcon, SupplyIcon, AddressIcon } from '../components/icons/GradientIcons';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const COLORS = ['#00c9a7', '#00a7e1', '#008ffb', '#0072ff'];

const InfoCard: React.FC<{ label: string; value: string | number; icon: React.ReactNode; copyable?: boolean }> = ({ label, value, icon, copyable = false }) => {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(value.toString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-theme-bg-alt p-4 rounded-lg border border-theme flex items-center">
      <div className="flex-shrink-0 mr-4 rtl:ml-4 rtl:mr-0 text-[#00a7e1]">
        {icon}
      </div>
      <div className="flex-grow">
        <p className="text-sm text-theme-secondary">{label}</p>
        <p className="text-theme-primary font-mono text-sm md:text-base break-all">{value}</p>
      </div>
      {copyable && (
        <button onClick={handleCopy} className="text-theme-tertiary hover:text-theme-primary transition-colors ltr:ml-4 rtl:mr-4 p-2 rounded-md bg-theme-bg hover:bg-opacity-50" title={copied ? t('tokenomicsPage.copied') : 'Copy'}>
          {copied ? (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
          )}
        </button>
      )}
    </div>
  );
};

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent } = props;

  return (
    <g>
      <text x={cx} y={cy - 10} dy={8} textAnchor="middle" fill="var(--text-primary)" className="font-bold text-2xl">
        {(percent * 100).toFixed(0)}%
      </text>
       <text x={cx} y={cy + 10} dy={8} textAnchor="middle" fill="var(--text-secondary)" className="text-sm">
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
    </g>
  );
};

// The Pie component from recharts has an incorrect type definition in this project's version of @types/recharts,
// missing the `activeIndex` prop. We cast it to `any` to bypass the erroneous type check.
const PieWithActiveIndexFix = Pie as any;

const TokenomicsPage: React.FC = () => {
  const { t } = useTranslation();
  const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.5 });
  const [contentRef, contentInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.2 });
  const [breakdownRef, breakdownInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.2 });
  const [activeIndex, setActiveIndex] = useState(0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };
  
  const tokenData = [
    { name: t('tokenomicsPage.dist_lp'), value: 40, icon: <LiquidityIcon className="h-10 w-10"/>, desc: t('tokenomicsPage.dist_lp_desc') },
    { name: t('tokenomicsPage.dist_treasury'), value: 30, icon: <TreasuryIcon className="h-10 w-10"/>, desc: t('tokenomicsPage.dist_treasury_desc') },
    { name: t('tokenomicsPage.dist_team'), value: 15, icon: <CommunityIcon className="h-10 w-10"/>, desc: t('tokenomicsPage.dist_team_desc') },
    { name: t('tokenomicsPage.dist_marketing'), value: 15, icon: <MarketingIcon className="h-10 w-10"/>, desc: t('tokenomicsPage.dist_marketing_desc') },
  ];

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('tokenomicsPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('tokenomicsPage.subtitle')}</p>
        </header>

        <div ref={contentRef} className="grid lg:grid-cols-5 gap-12 items-center">
          <div className={`lg:col-span-2 space-y-4 opacity-0 ${contentInView ? 'fade-in-left' : ''}`}>
            <InfoCard label={t('tokenomicsPage.name')} value="ARTOFELE" icon={<TagIcon className="w-6 h-6" />} />
            <InfoCard label={t('tokenomicsPage.symbol')} value="ART" icon={<TagIcon className="w-6 h-6" />} />
            <InfoCard label={t('tokenomicsPage.blockchain')} value="Solana" icon={<CubeIcon className="w-6 h-6" />} />
            <InfoCard label={t('tokenomicsPage.supply')} value="80,000,000 ART" icon={<SupplyIcon className="w-6 h-6" />} />
            <InfoCard label={t('tokenomicsPage.decimals')} value={9} icon={<SupplyIcon className="w-6 h-6" />} />
            <InfoCard label={t('tokenomicsPage.address')} value="4ZA513fFgBHuUQ8h64VRA8E7zL3mxd6PoDiTwXVJJ5P3" icon={<AddressIcon className="w-6 h-6" />} copyable />
          </div>

          <div className={`lg:col-span-3 w-full h-80 md:h-96 opacity-0 ${contentInView ? 'zoom-in delay-1' : ''}`}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <PieWithActiveIndexFix
                  activeIndex={activeIndex}
                  activeShape={renderActiveShape}
                  data={tokenData}
                  cx="50%"
                  cy="50%"
                  innerRadius="60%"
                  outerRadius="80%"
                  fill="#8884d8"
                  dataKey="value"
                  nameKey="name"
                  onMouseEnter={onPieEnter}
                >
                  {tokenData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className="focus:outline-none" />
                  ))}
                </PieWithActiveIndexFix>
                 <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--recharts-tooltip-bg)',
                    borderColor: 'var(--border-color)',
                    borderRadius: '0.5rem',
                    color: 'var(--text-primary)'
                  }}
                  itemStyle={{ color: 'var(--text-primary)' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

         <div ref={breakdownRef} className={`mt-20 opacity-0 ${breakdownInView ? 'fade-in-up' : ''}`}>
          <h3 className="text-3xl font-bold text-theme-primary text-center mb-10">{t('tokenomicsPage.chart_title')}</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {tokenData.map((item, index) => (
              <div 
                key={item.name} 
                className={`bg-theme-card p-6 rounded-lg border-b-4 transition-all duration-300 ${activeIndex === index ? 'shadow-xl scale-105' : 'shadow-md'}`}
                style={{ borderBottomColor: activeIndex === index ? COLORS[index] : 'var(--border-color)'}}
                onMouseEnter={() => setActiveIndex(index)}
              >
                <div className="flex items-center mb-3">
                  <div className="mr-4 rtl:ml-4 rtl:mr-0">{item.icon}</div>
                  <div>
                    <h4 className="text-xl font-bold text-theme-primary">{item.name}</h4>
                    <p className="text-2xl font-bold" style={{color: COLORS[index]}}>{item.value}%</p>
                  </div>
                </div>
                <p className="text-theme-secondary text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default TokenomicsPage;