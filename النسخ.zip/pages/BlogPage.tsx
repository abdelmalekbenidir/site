import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { blogPosts, BlogPost } from '../data/blogPosts';

// --- Scroll Animation Hook ---
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const BlogCard: React.FC<{ post: BlogPost; index: number }> = ({ post, index }) => {
    const { t, i18n } = useTranslation();
    const [ref, isInView] = useScrollAnimation({ triggerOnce: true });

    const postDate = new Date(post.date);
    const formattedDate = new Intl.DateTimeFormat(i18n.language, {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    }).format(postDate);

    return (
        <div ref={ref} className={`tilt-card opacity-0 ${isInView ? `fade-in-up delay-${index + 1}` : ''}`}>
            <Link to={`/blog/${post.slug}`} className="block bg-theme-card rounded-xl border border-theme overflow-hidden h-full group tilt-card-inner flex flex-col">
                <div className="overflow-hidden">
                    <img src={post.image} alt={t(`blogPosts.${post.slug}.title`)} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500 ease-in-out" />
                </div>
                <div className="p-6 flex flex-col flex-grow">
                    <h2 className="text-2xl font-bold text-theme-primary mb-3 group-hover:gradient-text transition-colors">{t(`blogPosts.${post.slug}.title`)}</h2>
                    <p className="text-sm text-theme-tertiary mb-4">
                        {t('blogPage.posted_by', { author: post.author })} {t('blogPage.posted_on', { date: formattedDate })}
                    </p>
                    <p className="text-theme-secondary leading-relaxed flex-grow">{t(`blogPosts.${post.slug}.excerpt`)}</p>
                    <div className="mt-4 text-[#00a7e1] font-semibold flex items-center gap-2">
                        {t('blogPage.read_more')}
                        <span className="transform transition-transform duration-300 group-hover:translate-x-1 rtl:group-hover:-translate-x-1">&rarr;</span>
                    </div>
                </div>
            </Link>
        </div>
    );
};

const BlogPage: React.FC = () => {
    const { t } = useTranslation();
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });

  return (
    <div className="py-20 bg-theme-bg-alt overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('blogPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4 max-w-3xl mx-auto">{t('blogPage.subtitle')}</p>
        </header>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
             <BlogCard key={post.slug} post={post} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
