import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { AiBrainIcon, PriceChartIcon, SentimentIcon, WhaleTrackerIcon, TokenToolIcon } from '../components/icons/GradientIcons';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const FeatureCard: React.FC<{ title: string; description: string; icon: React.ReactNode }> = ({ title, description, icon }) => (
  <div className="bg-theme-card p-8 rounded-xl border border-theme flex flex-col items-start h-full tilt-card-inner">
    <div className="mb-4">{icon}</div>
    <h3 className="text-2xl font-bold text-theme-primary mb-3">{title}</h3>
    <p className="text-theme-secondary leading-relaxed">{description}</p>
  </div>
);

const FeaturesPage: React.FC = () => {
    const { t } = useTranslation();
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
    const [gridRef, gridInView] = useScrollAnimation({ triggerOnce: true });

  const features = [
    { title: t('featuresPage.feature1_title'), description: t('featuresPage.feature1_desc'), icon: <AiBrainIcon className="h-12 w-12" /> },
    { title: t('featuresPage.feature2_title'), description: t('featuresPage.feature2_desc'), icon: <PriceChartIcon className="h-12 w-12" /> },
    { title: t('featuresPage.feature3_title'), description: t('featuresPage.feature3_desc'), icon: <SentimentIcon className="h-12 w-12" /> },
    { title: t('featuresPage.feature4_title'), description: t('featuresPage.feature4_desc'), icon: <WhaleTrackerIcon className="h-12 w-12" /> },
    { title: t('featuresPage.feature5_title'), description: t('featuresPage.feature5_desc'), icon: <TokenToolIcon className="h-12 w-12" /> },
  ];

  return (
    <div className="py-20 bg-theme-bg overflow-hidden">
      <div className="container mx-auto px-6">
        <header ref={headerRef} className={`text-center mb-16 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
          <h1 className="text-5xl font-extrabold text-theme-primary">{t('featuresPage.title')}</h1>
          <p className="text-xl text-theme-secondary mt-4">{t('featuresPage.subtitle')}</p>
        </header>

        <div ref={gridRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
             <div key={index} className={`tilt-card opacity-0 ${gridInView ? `fade-in-up delay-${index + 1}` : ''}`}>
                <FeatureCard title={feature.title} description={feature.description} icon={feature.icon} />
             </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturesPage;