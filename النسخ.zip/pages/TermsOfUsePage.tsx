import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';

// --- Scroll Animation Hook ---
// Replicated across pages to avoid creating new files.
const useScrollAnimation = (options?: { triggerOnce?: boolean; threshold?: number }) => {
  const [isInView, setIsInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (options?.triggerOnce) {
            observer.disconnect();
          }
        } else if (!options?.triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold: options?.threshold || 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]);

  return [ref, isInView] as const;
};

const TermsOfUsePage: React.FC = () => {
    const { t } = useTranslation();
    const [headerRef, headerInView] = useScrollAnimation({ triggerOnce: true });
    const [contentRef, contentInView] = useScrollAnimation({ triggerOnce: true, threshold: 0.1 });

    return (
        <div className="py-20 bg-theme-bg-alt overflow-hidden">
            <div className="container mx-auto px-6">
                <header ref={headerRef} className={`text-center mb-12 opacity-0 ${headerInView ? 'fade-in-up' : ''}`}>
                    <h1 className="text-5xl font-extrabold text-theme-primary">{t('termsOfUsePage.title')}</h1>
                    <p className="text-xl text-theme-secondary mt-4">{t('termsOfUsePage.subtitle')}</p>
                </header>
                <div ref={contentRef} className={`max-w-4xl mx-auto opacity-0 ${contentInView ? 'fade-in-up delay-1' : ''}`}>
                    <div className="bg-theme-card p-8 sm:p-12 rounded-lg border border-theme shadow-lg">
                        <div className="space-y-4 text-theme-secondary leading-relaxed">
                            <p><em>{t('termsOfUsePage.last_updated', { date: new Date().toLocaleDateString() })}</em></p>
                            <p>{t('termsOfUsePage.p1')}</p>
                            
                            <h3 className="text-2xl font-bold text-theme-primary !mt-6 !mb-3">{t('termsOfUsePage.h1')}</h3>
                            <p>{t('termsOfUsePage.p2')}</p>
                            
                            <h3 className="text-2xl font-bold text-theme-primary !mt-6 !mb-3">{t('termsOfUsePage.h2')}</h3>
                            <p>{t('termsOfUsePage.p3')}</p>

                            <h3 className="text-2xl font-bold text-theme-primary !mt-6 !mb-3">{t('termsOfUsePage.h3')}</h3>
                            <p>{t('termsOfUsePage.p4')}</p>

                            <h3 className="text-2xl font-bold text-theme-primary !mt-6 !mb-3">{t('termsOfUsePage.h4')}</h3>
                            <p>{t('termsOfUsePage.p5')}</p>

                            <h3 className="text-2xl font-bold text-theme-primary !mt-6 !mb-3">{t('termsOfUsePage.h5')}</h3>
                            <p>{t('termsOfUsePage.p6')}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TermsOfUsePage;
