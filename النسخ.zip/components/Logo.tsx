import React from 'react';
import { ArtofeleLogoIcon } from './icons/ArtofeleLogoIcon';

interface LogoProps {
  className?: string;
  imgClassName?: string;
}

const Logo: React.FC<LogoProps> = ({ className = '', imgClassName = '' }) => {
  return (
    <ArtofeleLogoIcon 
      className={`text-theme-primary ${className} ${imgClassName}`.trim()}
    />
  );
};

export default Logo;
