import React from 'react';
import { useTheme } from './ThemeContext';
import { SunIcon, MoonIcon } from './icons/ThemeIcons';

const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="theme-toggle"
      aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
    >
      <SunIcon className={`sun ${theme === 'light' ? 'active' : ''}`} />
      <MoonIcon className={`moon ${theme === 'dark' ? 'active' : ''}`} />
    </button>
  );
};

export default ThemeToggle;
