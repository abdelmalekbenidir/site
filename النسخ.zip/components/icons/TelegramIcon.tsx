
import React from 'react';

export const TelegramIcon: React.FC = () => (
  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-1.02.2-1.32l15.6-6.1c.76-.31 1.46.14 1.25.91L21 17.5c-.25.85-1.02 1.01-1.7.53l-4.01-2.98-3.93 3.82c-.38.37-.87.57-1.4.57l.19-4.17z" />
  </svg>
);
