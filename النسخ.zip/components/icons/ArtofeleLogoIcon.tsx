import React from 'react';

interface IconProps {
  className?: string;
}

// This component contains the ARTOFELE logo as an SVG.
// The 'A' part has a permanent gradient fill.
// The 'artofele' text part uses `fill="currentColor"` which allows it to adapt to the theme (black in light mode, white in dark mode) based on the parent's text color.
export const ArtofeleLogoIcon: React.FC<IconProps> = ({ className }) => (
  <svg 
    className={className}
    viewBox="0 0 322 100" 
    xmlns="http://www.w3.org/2000/svg" 
    aria-hidden="true"
    preserveAspectRatio="xMidYMid meet"
  >
    <defs>
      <linearGradient id="artofele-logo-gradient" x1="50%" y1="0%" x2="50%" y2="100%">
        <stop offset="0%" stopColor="#00c9a7" />
        <stop offset="50%" stopColor="#00a7e1" />
        <stop offset="100%" stopColor="#0072ff" />
      </linearGradient>
    </defs>
    <title>ARTOFELE Logo</title>
    {/* The 'A' logo part with gradient */}
    <path 
      d="M56.8 9.1L24.6 91h11.8l6.1-16.9h28.5l6.1 16.9h11.8L86.7 9.1h-7.9l-22 0zM83.6 64.9H61.3L72.5 31.1l11.1 33.8z" 
      fill="url(#artofele-logo-gradient)"
    />
    {/* The 'artofele' text part using currentColor for theme adaptability */}
    <text 
        x="108" 
        y="75" 
        fontFamily="'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"
        fontSize="48" 
        fontWeight="700" 
        fill="currentColor"
        letterSpacing="1"
    >
        artofele
    </text>
  </svg>
);