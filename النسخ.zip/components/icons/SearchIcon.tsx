
import React from 'react';

// Reusable gradient definition for icons
const IconGradient: React.FC = () => (
  <defs>
    <linearGradient id="artofele-gradient-search" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#00c9a7" />
      <stop offset="50%" stopColor="#00a7e1" />
      <stop offset="100%" stopColor="#0072ff" />
    </linearGradient>
  </defs>
);

interface IconProps {
  className?: string;
}

export const SearchIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <IconGradient />
    <path d="M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z" stroke="url(#artofele-gradient-search)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M21 21L16.65 16.65" stroke="url(#artofele-gradient-search)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
