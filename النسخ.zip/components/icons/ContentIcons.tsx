import React from 'react';

// Reusable gradient definition
const IconGradient: React.FC = () => (
  <defs>
    <linearGradient id="artofele-gradient-content" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#00c9a7" />
      <stop offset="50%" stopColor="#00a7e1" />
      <stop offset="100%" stopColor="#0072ff" />
    </linearGradient>
  </defs>
);

interface IconProps {
  className?: string;
}

export const PageIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <IconGradient />
    <path d="M9 4H7C5.89543 4 5 4.89543 5 6V18C5 19.1046 5.89543 20 7 20H17C18.1046 20 19 19.1046 19 18V10L14 4H9Z" stroke="url(#artofele-gradient-content)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14 4V10H19" stroke="url(#artofele-gradient-content)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const BlogIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <IconGradient />
    <path d="M16 4H8C6.89543 4 6 4.89543 6 6V18C6 19.1046 6.89543 20 8 20H16C17.1046 20 18 19.1046 18 18V6C18 4.89543 17.1046 4 16 4Z" stroke="url(#artofele-gradient-content)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 16H14" stroke="url(#artofele-gradient-content)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M10 12H14" stroke="url(#artofele-gradient-content)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M10 8H14" stroke="url(#artofele-gradient-content)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
