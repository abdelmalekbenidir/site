import React from 'react';

// Reusable gradient definition for all icons
const IconGradient: React.FC = () => (
  <defs>
    <linearGradient id="artofele-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#00c9a7" />
      <stop offset="50%" stopColor="#00a7e1" />
      <stop offset="100%" stopColor="#0072ff" />
    </linearGradient>
  </defs>
);

interface IconProps {
  className?: string;
}

export const AiBrainIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="url(#artofele-gradient)" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path fillRule="evenodd" clipRule="evenodd" d="M12 2C9.23858 2 7 4.23858 7 7V7.5C7 7.77614 6.77614 8 6.5 8H6C3.79086 8 2 9.79086 2 12C2 14.2091 3.79086 16 6 16H6.5C6.77614 16 7 16.2239 7 16.5V17C7 19.7614 9.23858 22 12 22C14.7614 22 17 19.7614 17 17V16.5C17 16.2239 17.2239 16 17.5 16H18C20.2091 16 22 14.2091 22 12C22 9.79086 20.2091 8 18 8H17.5C17.2239 8 17 7.77614 17 7.5V7C17 4.23858 14.7614 2 12 2ZM5 12C5 11.4477 5.44772 11 6 11V13C5.44772 13 5 12.5523 5 12ZM10 7H9V9H10V7ZM12 5H11V6H12V5ZM14 7H13V9H14V7ZM15 11H18C18.5523 11 19 11.4477 19 12C19 12.5523 18.5523 13 18 13H15V11ZM10 15H9V17H10V15ZM12 18H11V19H12V18ZM14 15H13V17H14V15Z"/>
    </svg>
);

export const SentimentIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M7 17C5.89543 17 5 16.1046 5 15V11C5 9.89543 5.89543 9 7 9H12C13.1046 9 14 9.89543 14 11V15C14 16.1046 13.1046 17 12 17H8.91667L7 19V17Z" stroke="url(#artofele-gradient)" strokeWidth="1.5"/>
        <path d="M19 8V7C19 5.89543 18.1046 5 17 5H12C10.8954 5 10 5.89543 10 7V8" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
);

export const WhaleTrackerIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M12 13V18C12 20.2091 10.2091 22 8 22C5.79086 22 4 20.2091 4 18C4 16.9463 4.44499 15.9933 5.17157 15.2677C5.89816 14.5422 6.8512 14.1011 7.82843 14.0048C8.80565 13.9085 9.75484 14.1205 10.5401 14.6067C11.3254 15.0929 12 15.8273 12 16.6391V13ZM12 13C12 10.7909 13.7909 9 16 9C18.2091 9 20 10.7909 20 13C20 14.0537 19.555 15.0067 18.8284 15.7323C18.1018 16.4578 17.1488 16.8989 16.1716 16.9952C15.1943 17.0915 14.2452 16.8795 13.4599 16.3933C12.6746 15.9071 12 15.1727 12 14.3609V13Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M7 6C7 6 9 3 12 3C15 3 17 6 17 6" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const TransparencyIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 21C16.9033 21 21.0967 17.0919 22 12.4C21.0967 7.70812 16.9033 3.8 12 3.8C7.09671 3.8 2.90329 7.70812 2 12.4C2.90329 17.0919 7.09671 21 12 21Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const InnovationIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M8.5 19H15.5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 16V19" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M9 16C9 13.3333 12 11.5 12 8C12 4.5 14.5 2 12 2C9.5 2 7 4.5 7 8C7 11.5 10 13.3333 10 16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const CommunityIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M17 20C17 17.7909 15.2091 16 13 16C10.7909 16 9 17.7909 9 20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M13 12C13 10.3431 11.6569 9 10 9C8.34315 9 7 10.3431 7 12C7 13.6569 8.34315 15 10 15C11.6569 15 13 13.6569 13 12Z" stroke="url(#artofele-gradient)" strokeWidth="1.5"/>
        <path d="M21 20C21 17.7909 19.2091 16 17 16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M16 12C16 10.3431 14.6569 9 13 9" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M7 20C7 17.7909 5.20914 16 3 16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
);

export const PriceChartIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M3 17L9 11L13 15L21 7" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M14 7H21V14" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const TokenToolIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M12 8V16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M8 12H16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="url(#artofele-gradient)" strokeWidth="1.5"/>
    </svg>
);

export const EmailIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M4 7.00005L10.2 11.65C11.2667 12.45 12.7333 12.45 13.8 11.65L20 7" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <rect x="2" y="5" width="20" height="14" rx="2" stroke="url(#artofele-gradient)" strokeWidth="1.5"/>
    </svg>
);

// --- Icons for Tokenomics Page ---

export const LiquidityIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M12 2.69126C12 2.69126 5 9.69126 5 14.6913C5 18.6118 8.13401 21.6913 12 21.6913C15.866 21.6913 19 18.6118 19 14.6913C19 9.69126 12 2.69126 12 2.69126Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 11.6913C10.3431 11.6913 9 13.0344 9 14.6913" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const TreasuryIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M4 8H20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M6 12H18" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 16H19" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M2 20V4C2 2.89543 2.89543 2 4 2H20C21.1046 2 22 2.89543 22 4V20C22 21.1046 21.1046 22 20 22H4C2.89543 22 2 21.1046 2 20Z" stroke="url(#artofele-gradient)" strokeWidth="1.5"/>
    </svg>
);

export const MarketingIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M7 17V13" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 17V10" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17 17V7" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 3V19C3 19.5523 3.44772 20 4 20H20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const TagIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M20.25 12.0001L12 20.2501L3.75 12.0001L12 3.75006L20.25 12.0001Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const CubeIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M21 16.5L12 21.75L3 16.5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 7.5L12 2.25L21 7.5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 7.5V16.5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M21 7.5V16.5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 2.25V12" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M21 7.5L12 12L3 7.5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const SupplyIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M17 17L21 17" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 17L13 17" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17 12L19 12" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 12L13 12" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17 7L21 7" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 7L13 7" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const AddressIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M4 6H20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M4 12H20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M4 18H20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

// --- Icons for Partnership Page ---

export const PartnershipIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M16 5.99998C16 4.34313 14.6569 2.99998 13 2.99998C11.3431 2.99998 10 4.34313 10 5.99998V11.5L8.46154 10.3846C7.81846 9.93291 7 10.388 7 11.1538V18.1538C7 18.6205 7.37949 19 7.84615 19H12M12 19L18.1538 14.8462C18.6625 14.498 19 13.8846 19 13.1538V6.15383C19 5.68716 18.6205 5.30768 18.1538 5.30768H13L12 19Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const TechIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M7 8L3 12L7 16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17 8L21 12L17 16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M14 4L10 20" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const MarketingCollaborationIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <path d="M9.10938 3.28043L3.48622 8.1721C2.86475 8.72023 2.8258 9.71261 3.3934 10.3153L3.62688 10.5641C4.18029 11.1491 5.11192 11.2312 5.77688 10.741L12.1885 5.96593C12.8534 5.47576 12.9304 4.54249 12.377 3.95753L12.1435 3.70874C11.5759 3.10603 10.5835 3.14925 10.0159 3.71791L9.10938 3.28043Z" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M10.0156 3.71791L3.60401 8.49298" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M8 12L4 16" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M14 11L18 7" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M15.4287 15.1716L18.2571 18" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M11.6367 19L14.4651 21.8284" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M4 16H8C8 16 10.2288 15.4716 11.5 14C12.7712 12.5284 14 11 14 11L15.3431 9.65685C16.9003 8.10023 18.1004 8.10086 19.6569 9.65685C21.2134 11.2134 21.2134 13.7866 19.6569 15.3431C18.1009 16.9001 16.9002 16.8995 15.3431 15.3431L14 14" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const DataProviderIcon: React.FC<IconProps> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradient />
        <ellipse cx="12" cy="5" rx="9" ry="3" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M21 12c0 1.6569-4.0294 3-9 3s-9-1.3431-9-3" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 5v14c0 1.6569 4.0294 3 9 3s9-1.3431 9-3V5" stroke="url(#artofele-gradient)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);