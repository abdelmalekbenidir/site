import React from 'react';

export const MediumIcon: React.FC = () => (
  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M13.54 12a6.8 6.8 0 0 1-6.77 6.82A6.8 6.8 0 0 1 0 12a6.8 6.8 0 0 1 6.77-6.82A6.8 6.8 0 0 1 13.54 12z"></path>
    <path d="M20.92 12A3.11 3.11 0 0 1 17.8 8.89a3.11 3.11 0 0 1 3.12-3.11A3.11 3.11 0 0 1 24 8.89a3.11 3.11 0 0 1-3.08 3.11z"></path>
    <path d="M17.81 12a.92.92 0 0 1-.91-1V6.2a.92.92 0 0 1 1.83 0V11a.92.92 0 0 1-.92 1z"></path>
  </svg>
);
