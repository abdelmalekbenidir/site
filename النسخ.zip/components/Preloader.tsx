import React from 'react';

interface PreloaderProps {
  isFadingOut: boolean;
}

const Preloader: React.FC<PreloaderProps> = ({ isFadingOut }) => {
  return (
    <div className={`preloader ${isFadingOut ? 'fade-out' : ''}`}>
      <img 
        src="https://www.artofele.com/logo.png" 
        alt="ARTOFELE Logo" 
        className="preloader-logo"
      />
    </div>
  );
};

export default Preloader;