import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { GoogleGenAI } from '@google/genai';
import { SendIcon, CloseIcon } from './icons/WidgetIcons';

interface Message {
    sender: 'user' | 'ai';
    text: string;
}

interface AiAssistantWidgetProps {
    isOpen: boolean;
    onClose: () => void;
}

const AiAssistantWidget: React.FC<AiAssistantWidgetProps> = ({ isOpen, onClose }) => {
    const { t } = useTranslation();
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        if (isOpen) {
            // Set initial welcome message only once when the component mounts or opens for the first time
            if (messages.length === 0) {
                setMessages([{ sender: 'ai', text: t('aiAssistantWidget.welcome_message') }]);
            }
            // Focus input when widget opens
            setTimeout(() => inputRef.current?.focus(), 400); // Delay to allow for transition
        }
    }, [isOpen, t]);

    useEffect(scrollToBottom, [messages, loading]);

    const artofeleSystemInstruction = `You are an expert assistant for the ARTOFELE project. ARTOFELE is a decentralized token (symbol: ART) on the Solana blockchain, connected to an AI-powered cryptocurrency analytics platform. The project focuses on transparency, innovation, and community growth. Total Supply: 80,000,000 ART. Mint Address: 4ZA513fFgBHuUQ8h64VRA8E7zL3mxd6PoDiTwXVJJ5P3. Key features include AI-Powered Token Analysis, Live Price Tracking, Social Sentiment Analysis, Whale Tracking, and a Solana Token Creation Tool. ART can be bought on Solana DEXs like Raydium or Jupiter. Your goal is to answer questions based ONLY on this information about ARTOFELE. If a question is outside this scope, politely state that you can only answer questions about ARTOFELE. Keep answers concise, helpful, and formatted for readability using markdown for lists or bold text.`;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || loading) return;

        const newUserMessage: Message = { sender: 'user', text: input };
        setMessages(prev => [...prev, newUserMessage]);
        setInput('');
        setLoading(true);
        setError('');

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: input,
                config: {
                    systemInstruction: artofeleSystemInstruction,
                }
            });

            const aiResponse: Message = { sender: 'ai', text: response.text };
            setMessages(prev => [...prev, aiResponse]);

        } catch (err) {
            console.error(err);
            const errorMessage: Message = { sender: 'ai', text: t('aiAssistantWidget.error') };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className={`ai-widget-container bg-theme-card border border-theme ${isOpen ? '' : 'hidden'}`}>
            <header className="ai-widget-header p-4 flex justify-between items-center flex-shrink-0">
                <h3 className="text-lg font-bold text-white dark:text-theme-primary">{t('aiAssistantWidget.header_title')}</h3>
                <button onClick={onClose} className="text-white dark:text-theme-secondary hover:opacity-80 transition-opacity">
                    <CloseIcon className="w-6 h-6" />
                </button>
            </header>
            
            <div className="flex-grow p-4 overflow-y-auto ai-widget-messages">
                <div className="space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`message-bubble p-3 rounded-lg ${msg.sender}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    {loading && (
                        <div className="flex justify-start">
                            <div className="message-bubble p-3 rounded-lg ai">
                               <div className="typing-indicator">
                                    <span></span><span></span><span></span>
                               </div>
                            </div>
                        </div>
                    )}
                </div>
                <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-theme flex-shrink-0">
                <form onSubmit={handleSubmit} className="flex items-center gap-2">
                    <input
                        ref={inputRef}
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder={t('aiAssistantWidget.placeholder')}
                        className="w-full bg-theme-bg-alt border border-theme rounded-full py-2 px-4 text-theme-primary focus:ring-2 focus:ring-[#00a7e1] focus:border-transparent transition disabled:opacity-50"
                        disabled={loading}
                        aria-label={t('aiAssistantWidget.placeholder')}
                    />
                    <button
                        type="submit"
                        disabled={loading || !input.trim()}
                        className="gradient-bg text-white rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label="Send message"
                    >
                        <SendIcon className="w-5 h-5" />
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AiAssistantWidget;