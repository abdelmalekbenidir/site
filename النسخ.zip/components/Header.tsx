import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { TwitterIcon } from './icons/TwitterIcon';
import { TelegramIcon } from './icons/TelegramIcon';
import ThemeToggle from './ThemeToggle';
import Logo from './Logo';
import LanguageSwitcher from './LanguageSwitcher';

const Header: React.FC = () => {
  const { t } = useTranslation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { name: t('header.home'), path: '/' },
    { name: t('header.about'), path: '/about' },
    { name: t('header.features'), path: '/features' },
    { name: t('header.tokenomics'), path: '/tokenomics' },
    { name: t('header.roadmap'), path: '/roadmap' },
    { name: t('header.blog'), path: '/blog' },
    { name: t('header.partners'), path: '/partnership' },
    { name: t('header.faq'), path: '/faq' },
    { name: t('header.contact'), path: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-theme backdrop-blur-md" style={{ backgroundColor: 'var(--header-background)'}}>
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <Logo imgClassName="h-10 w-auto" />
        </Link>
        <nav className="hidden md:flex items-center space-x-6">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              end={link.path === '/'}
              className="nav-link-underline text-theme-secondary transition-colors font-semibold whitespace-nowrap"
            >
              {link.name}
            </NavLink>
          ))}
        </nav>
        <div className="hidden md:flex items-center space-x-2">
          <ThemeToggle />
          <LanguageSwitcher />
          <div className="w-px h-6 bg-theme-border !mx-3"></div>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-icon transition-colors p-1"><TwitterIcon /></a>
          <a href="https://telegram.org" target="_blank" rel="noopener noreferrer" className="social-icon transition-colors p-1"><TelegramIcon /></a>
        </div>
        <div className="md:hidden flex items-center gap-2">
            <ThemeToggle />
            <LanguageSwitcher />
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-theme-primary focus:outline-none p-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
            </svg>
          </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-theme-bg border-t border-theme">
          <nav className="flex flex-col items-center space-y-4 py-4">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                end={link.path === '/'}
                onClick={() => setIsMenuOpen(false)}
                className="nav-link-underline text-theme-secondary transition-colors font-semibold text-lg"
              >
                {link.name}
              </NavLink>
            ))}
            <div className="flex items-center space-x-6 pt-4">
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-icon transition-colors"><TwitterIcon /></a>
              <a href="https://telegram.org" target="_blank" rel="noopener noreferrer" className="social-icon transition-colors"><TelegramIcon /></a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;