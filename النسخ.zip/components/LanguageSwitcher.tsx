import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { GlobeIcon } from './icons/GlobeIcon';

const languages = [
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'ar', name: 'العربية', flag: '🇸🇦' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' },
];

const LanguageSwitcher: React.FC = () => {
    const { i18n } = useTranslation();
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const changeLanguage = (code: string) => {
        i18n.changeLanguage(code);
        setIsOpen(false);
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <div className="relative" ref={dropdownRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="theme-toggle"
                aria-haspopup="true"
                aria-expanded={isOpen}
                aria-label={i18n.t('languageSwitcher.label')}
            >
                <GlobeIcon className="w-5 h-5" />
            </button>
            {isOpen && (
                <div className="absolute top-full mt-2 end-0 w-48 bg-theme-card border border-theme rounded-lg shadow-lg z-50 py-1">
                    <ul>
                        {languages.map(({ code, name, flag }) => (
                            <li key={code}>
                                <button
                                    onClick={() => changeLanguage(code)}
                                    className="w-full text-start flex items-center space-x-3 px-4 py-2 hover:bg-theme-bg-alt transition-colors duration-200"
                                >
                                    <span className="text-xl">{flag}</span>
                                    <span className="text-theme-primary">{name}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default LanguageSwitcher;
