import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { TwitterIcon } from './icons/TwitterIcon';
import { TelegramIcon } from './icons/TelegramIcon';
import { MediumIcon } from './icons/MediumIcon';
import Logo from './Logo';

const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-theme-bg-alt border-t border-theme">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col items-center text-center">
          <div className="solana-logo-container mb-2">
              <div className="solana-logo-3d">
                  <div className="solana-part solana-part-1"></div>
                  <div className="solana-part solana-part-2"></div>
                  <div className="solana-part solana-part-3"></div>
              </div>
          </div>
          <Logo imgClassName="h-12 w-auto" className="mb-4" />
          <p className="text-theme-secondary mb-6 max-w-md">
            {t('footer.description')}
          </p>
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 my-6 text-theme-secondary font-medium">
            <Link to="/about" className="hover:text-theme-primary transition-colors">{t('header.about')}</Link>
            <Link to="/features" className="hover:text-theme-primary transition-colors">{t('header.features')}</Link>
            <Link to="/blog" className="hover:text-theme-primary transition-colors">{t('header.blog')}</Link>
            <Link to="/partnership" className="hover:text-theme-primary transition-colors">{t('header.partners')}</Link>
            <Link to="/contact" className="hover:text-theme-primary transition-colors">{t('header.contact')}</Link>
          </div>
          <div className="flex space-x-6 mt-8 mb-6">
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-icon transition-transform duration-300 hover:scale-110">
              <TwitterIcon />
            </a>
            <a href="https://telegram.org" target="_blank" rel="noopener noreferrer" className="social-icon transition-transform duration-300 hover:scale-110">
              <TelegramIcon />
            </a>
            <a href="https://medium.com/@artofele" target="_blank" rel="noopener noreferrer" className="social-icon transition-transform duration-300 hover:scale-110">
              <MediumIcon />
            </a>
          </div>
          <div className="text-theme-tertiary text-sm flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
            <span>{t('footer.copyright', { year: new Date().getFullYear() })}</span>
            <span className="hidden sm:inline">|</span>
            <Link to="/privacy-policy" className="hover:text-theme-primary transition-colors hover:underline">
              {t('footer.privacy_policy')}
            </Link>
            <span className="hidden sm:inline">|</span>
            <Link to="/terms-of-use" className="hover:text-theme-primary transition-colors hover:underline">
              {t('footer.terms_of_use')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;