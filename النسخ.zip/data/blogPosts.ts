export interface BlogPost {
    slug: string;
    author: string;
    date: string; // YYYY-MM-DD
    image: string;
}

export const blogPosts: BlogPost[] = [
    {
        slug: 'ai-in-crypto',
        author: "Alex 'Vision' Chen",
        date: '2024-07-26',
        image: 'https://images.unsplash.com/photo-1677756119517-756a188d2d94?q=80&w=1974&auto=format&fit=crop',
    },
    {
        slug: 'understanding-solana',
        author: "Ben 'Nexus' Carter",
        date: '2024-07-22',
        image: 'https://images.unsplash.com/photo-1642104792297-a745c955212c?q=80&w=2070&auto=format&fit=crop',
    },
    {
        slug: 'community-is-key',
        author: "Carla 'Aura' Rodriguez",
        date: '2024-07-18',
        image: 'https://images.unsplash.com/photo-1529070474420-a35970fc4a2a?q=80&w=2070&auto=format&fit=crop',
    },
];
